public class FinancialForecast {
    public static double predictFutureValue(int years, double initialAmount, double growthRate) {
        if (years == 0) {
            return initialAmount;
        } else {
            return predictFutureValue(years - 1, initialAmount, growthRate) * (1 + growthRate);
        }
    }
    public static void main(String[] args) {
        double initialAmount = 10000;      
        double annualGrowthRate = 0.08;    
        int targetYears = 5;
        double futureValue = predictFutureValue(targetYears, initialAmount, annualGrowthRate);
        System.out.printf("Predicted future value after %d years: ₹%.2f\n", targetYears, futureValue);
    }
}