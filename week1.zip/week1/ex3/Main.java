public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Shoes", "Fashion"),
            new Product(102, "Laptop", "Electronics"),
            new Product(103, "Phone", "Electronics"),
            new Product(104, "Watch", "Accessories"),
            new Product(105, "Shirt", "Fashion")
        };

        System.out.println("Linear Search:");
        Product result1 = SearchEngine.linearSearch(products, "Phone");
        System.out.println(result1 != null ? result1 : "Product not found");

        System.out.println("\nBinary Search:");
        SearchEngine.sortProducts(products);
        Product result2 = SearchEngine.binarySearch(products, "Phone");
        System.out.println(result2 != null ? result2 : "Product not found");
    }
}
